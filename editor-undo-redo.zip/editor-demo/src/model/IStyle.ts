export interface IStyle {
    [key: string]: string;
}