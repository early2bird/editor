
let i = 0

export const generateNodeId = () => `${i++}`