import React, {KeyboardEvent, ClipboardEvent, useState} from 'react';
import { Document as DocumentModel } from '../model/Document';
import { Document } from './Document'
import { Paragraph } from '../model/Paragraph';
import { generateNodeId } from '../util/id-generator';

const undoStack: DocumentModel[] = []
const redoStack: DocumentModel[] = []

export function EditArea(props: {data: any}) {
    // const document = DocumentModel.create(props.data)
    const [document, setDocument] = useState(DocumentModel.create(props.data))

    const onKeyDown = (event: KeyboardEvent) => {
        if (event.key === 'Shift' ||
            event.key === 'Ctrl' ||
            event.key === 'Alt' ||
            event.key === 'Meta')
        {
            return
        }

        if ((event.key === 'c' || event.key === 'v') && event.metaKey) {
            return
        }
        event.preventDefault()

        if (event.key === 'Backspace') {
            deleteText(true)
        } else if (event.key === 'Delete') {
            deleteText(false)
        } else if (event.key === 'b' && event.metaKey) {
            toggleBold()
        } else if (event.key === 'c' && event.metaKey && event.shiftKey) {
            applyCenter()
        } else if (event.key === 'Enter') {
            splitParagraph()
        } else if (event.key === 'z' && event.metaKey && event.shiftKey) {
            redo()
        } else if (event.key === 'z' && event.metaKey) {
            undo()
        } else {
            insertText(event)
        }
    }

    const undo = () => {
        if (undoStack.length === 0) {
            return
        }
        const undoDocument = undoStack.pop()
        if (undoDocument) {
            redoStack.push(document)
            setDocument(undoDocument)
        }
    }

    const redo = () => {
        if (redoStack.length === 0) {
            return
        }
        const redoDocument = redoStack.pop()
        if (redoDocument) {
            undoStack.push(document)
            setDocument(redoDocument)
        }
    }

    const exec = (name: string, args: any) => {
        const newDocument = DocumentModel.create(document)
        const operationMap: {[id:string]: Function} = {
            insertText: (args: any) => {
                const { id, offset, text } = args
                newDocument.insertText(id, offset, text)
            },
            deleteText: (args: any) => {
                const { id, start, length } = args
                newDocument.deleteText(id, start, length)
            }
        }
        operationMap[name](args)
        undoStack.push(document)
        redoStack.slice(0,0)
        setDocument(newDocument)
    }

    const insertText = (event: KeyboardEvent) => {
        const sel = window.getSelection()
        if (!sel || !sel.rangeCount) {
            return
        }

        const range = sel.getRangeAt(0)
        const startContainer = range.startContainer
        const parentEl = startContainer.parentElement
        const startOffset = range.startOffset
        const text = event.key
        // TODO
        if (!range.collapsed) {
            return
        }

        if (!parentEl) {
            return
        }

        exec('insertText', {
            id: parentEl.id,
            offset: startOffset,
            text
        })

        setTimeout(() => {
            range.setEnd(startContainer, startOffset + text.length)
            range.setStart(startContainer, startOffset + text.length)
            sel.addRange(range)
        })
    }

    const deleteText = (backward: boolean) => {
        const sel = window.getSelection()
        if (!sel || !sel.rangeCount) {
            return
        }

        const range = sel.getRangeAt(0)
        const startContainer = range.startContainer
        const parentEl = startContainer.parentElement
        const startOffset = range.startOffset
        // TODO
        if (!range.collapsed) {
            return
        }

        if (!parentEl) {
            return
        }

        const start = backward ? startOffset - 1: startOffset
        if (start < 0) {
            return
        }

        exec('deleteText', {
            id: parentEl.id,
            start,
            length: 1
        })

        setTimeout(() => {
            range.setEnd(startContainer, start)
            range.setStart(startContainer, start)
            sel.addRange(range)
        })
    }

    const toggleBold = () => {
        const sel = window.getSelection()
        if (!sel || !sel.rangeCount) {
            return
        }

        const range = sel.getRangeAt(0)

        const startContainer = range.startContainer
        const startParentEl = startContainer.parentElement
        const startOffset = range.startOffset
        const endContainer = range.endContainer
        const endParentEl = endContainer.parentElement
        const endOffset = range.endOffset
        // TODO
        if (range.collapsed) {
            return
        }

        if (!startParentEl || !endParentEl) {
            return
        }

        document.addInlineStyle(startParentEl.id, startOffset, endParentEl.id, endOffset, 'fontWeight', 'bold')
        setDocument(DocumentModel.create(document))

        setTimeout(() => {
            range.setEnd(endContainer, endOffset)
            range.setStart(endContainer, endOffset)
            sel.addRange(range)
        })
    }

    const applyCenter = () => {
        const sel = window.getSelection()
        if (!sel || !sel.rangeCount) {
            return
        }

        const range = sel.getRangeAt(0)
        const startContainer = range.startContainer
        const parentEl = startContainer.parentElement
        const startOffset = range.startOffset
        // TODO
        if (!range.collapsed) {
            return
        }

        if (!parentEl) {
            return
        }
        document.addParagraphStyle(parentEl.id, startOffset, 'textAlign', 'center')
        setDocument(DocumentModel.create(document))

        setTimeout(() => {
            range.setEnd(startContainer, startOffset)
            range.setStart(startContainer, startOffset)
            sel.addRange(range)
        })
    }

    const splitParagraph = () => {
        const sel = window.getSelection()
        if (!sel || !sel.rangeCount) {
            return
        }

        const range = sel.getRangeAt(0)
        const startContainer = range.startContainer
        const parentEl = startContainer.parentElement
        const startOffset = range.startOffset
        // TODO
        if (!range.collapsed) {
            return
        }

        if (!parentEl) {
            return
        }
        document.splitParagraph(parentEl.id, startOffset)
        setDocument(DocumentModel.create(document))

        setTimeout(() => {
            range.setEnd(startContainer, startOffset)
            range.setStart(startContainer, startOffset)
            sel.addRange(range)
        })
    }

    return (
        <div className="editArea"
            contentEditable="true"
            onKeyDown={onKeyDown}
        >
            <Document document = {document}/>
        </div>
    );
}




